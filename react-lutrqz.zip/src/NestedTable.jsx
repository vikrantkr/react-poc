import React, { useState } from "react";
import Pagination from "./Pagination";
const nestedTable = props => {
  const [currentPage, setCurrentPage] = useState(1);
  const [perPage, setPerPage] = useState(4);
  const indexOfLast = currentPage * perPage;
  const indexOfFirst = indexOfLast - perPage;

  if (props.pagination) {
    const current = props.tableData.slice(indexOfFirst, indexOfLast);
  } else {
    const current = props.tableData;
  }
  const paginate = pageNumber => {
    setCurrentPage(pageNumber);
  };

  // const arr=[...current];
  // const arr1={...arr};
  // alert("hi---"+JSON.stringify(current))
  const compareBy = key => {
    return function(a, b) {
      if (a[key] < b[key]) return -1;
      if (a[key] > b[key]) return 1;
      return 0;
    };
  };

  const sortBy = key => {
    var arrayCopy = [...current];
    for (var j = 0; j < arrayCopy.length; j++) {
      arrayCopy.sort(compareBy(key));
    }
  };

  const table = current.map((tData, index) => {
    if (typeof tData.name === "object") {
      const nested = (
        <>
          <tr>
            <td>{tData.name.firstname}</td>
            <td rowSpan="2">{tData.companyName}</td>
          </tr>
          <tr>
            <td>{tData.name.lastname}</td>
          </tr>
        </>
      );
    }
    return (
      <tbody key={index}>
        {typeof tData.name === "object" ? (
          nested
        ) : (
          <tr>
            <td>{tData.name}</td>
            <td>{tData.companyName}</td>
          </tr>
        )}
      </tbody>
    );
  });

  return (
    <div className="container">
      <table className="table table-bordered">
        <thead>
          <tr>
            <th>{props.headerConfig.name}</th>
            <th onClick={() => sortBy("companyName")}>
              {props.headerConfig.companyName}
            </th>
          </tr>
        </thead>
        {table}
      </table>
      {props.pagination ? (
        <Pagination
          perPage={perPage}
          total={props.tableData.length}
          paginate={paginate}
        />
      ) : null}
    </div>
  );
};

export default nestedTable;
