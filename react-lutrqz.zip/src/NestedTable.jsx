import React, { useState } from 'react';
import Pagination from './Pagination';
const nestedTable=(props)=>{

  const [currentPage,setCurrentPage]= useState(1);
  const [perPage,setPerPage]= useState(5);

  const indexOfLast= currentPage * perPage;
  const indexOfFirst= indexOfLast - perPage;
  const current=props.tableData.slice(indexOfFirst, indexOfLast);

  const paginate=(pageNumber)=>{setCurrentPage(pageNumber)};

  
    var table= current.map((tData,index)=>{
        if(typeof(tData.name)=== 'object'){
       tData.name=tData.name.firstname + ' '+tData.name.lastname;
      }
      return (<tbody key={index}>
              <tr>
                <td>{tData.name}</td>
                <td>{tData.companyName}</td>
              </tr>
              </tbody>);
    })
      
      return(
       <div className="container">          
          <table className="table table-bordered">
            <thead>
              <tr>
                <th>{props.headerConfig.name}</th>
                <th>{props.headerConfig.companyName}</th>
              </tr>
            </thead>
            {table}
          </table>
          <Pagination perPage={perPage} total={props.tableData.length} paginate={paginate}/>
        </div>
      )
  
}

export default nestedTable;