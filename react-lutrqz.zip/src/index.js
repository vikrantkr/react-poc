import React, { Component } from "react";
import { render } from "react-dom";
import "./style.css";
import NestedTable from "./NestedTable";
class App extends Component {
  constructor() {
    super();
    this.state = {
      headersConfig: {
        name: "Full Name",
        companyName: "Company Name"
      },
      tableData: [
        {
          name: { firstname: "John ", lastname: " Jacobs" },
          companyName: "Hudson, Rohan and Shanahan"
        },
        {
          name: "Candace Jast",
          companyName: "Schuppe, Jerde and Mann"
        },
        {
          name: { firstname: "Ram ", lastname: " Kumar" },
          companyName: "Hudson, Rohan and Shanahan"
        },
        {
          name: { firstname: "John ", lastname: " Jacobs" },
          companyName: "Hudson, Rohan and Shanahan"
        },
        {
          name: { firstname: "John ", lastname: " Jacobs" },
          companyName: "Hudson, Rohan and Shanahan"
        },
        {
          name: "Candace Jast",
          companyName: "Schuppe, Jerde and Mann"
        },
        {
          name: "Candace Jast",
          companyName: "Schuppe, Jerde and Mann"
        },
        {
          name: "Candace Jast",
          companyName: "Schuppe, Jerde and Mann"
        },
        {
          name: "Candace Jast",
          companyName: "Schuppe, Jerde and Mann"
        },
        {
          name: { firstname: "Ram ", lastname: " Kumar" },
          companyName: "Hudson, Rohan and Shanahan"
        }
      ]
    };
  }

  render() {
    return (
      <div>
        <h1 />
        <NestedTable
          headerConfig={this.state.headersConfig}
          tableData={this.state.tableData}
          pagination={true}

        />
      </div>
    );
  }
}

render(<App />, document.getElementById("root"));
